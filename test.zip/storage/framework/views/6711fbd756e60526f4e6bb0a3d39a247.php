

<?php $__env->startSection('content'); ?>
<div class="row justify-content-between align-items-center mb-3">
    <h1 class="col-sm-6 col-lg-8 mb-0">Books</h1>
    <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary btn-sm col-sm-6 col-lg-4 mb-3 mb-sm-0">Add Book</a>   
        
    <table class="table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Description</th>    
                <th>Publisher</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Categories</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($book->title); ?></td>
                    <td><?php echo e($book->description); ?></td>
                    <td><?php echo e($book->publisher->name); ?></td>
                    <td><?php echo e($book->price); ?></td> 
                    <td><?php echo e($book->stock); ?></td>
                    <td><?php $__currentLoopData = $book->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($category->name); ?>

                        <?php if(!$loop->last): ?>, <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('books.edit', $book)); ?>" class="btn btn-primary btn-sm mr-2">
                            Edit
                        </a>
                        <form action="<?php echo e(route('books.destroy', $book)); ?>" method="post" style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this book?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asia_quest_test\resources\views/books/index.blade.php ENDPATH**/ ?>